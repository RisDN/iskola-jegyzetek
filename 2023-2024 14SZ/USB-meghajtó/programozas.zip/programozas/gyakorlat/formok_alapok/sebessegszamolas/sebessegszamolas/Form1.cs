﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sebessegszamolas
{
    public partial class frmsebesseg : Form
    {
        public frmsebesseg()
        {
            InitializeComponent();
        }

        private void btszamitas_Click(object sender, EventArgs e)
        {
            double ut = Convert.ToDouble(txut.Text);
            double ido = Convert.ToDouble(txido.Text);
            double sebesseg =Math.Round(ut / ido,1);
            txsebesseg.Text = Convert.ToString(sebesseg);
         //   txsebesseg.Enabled = true;
            if (sebesseg > 50)
                txsebesseg.BackColor = Color.Red;
               // txsebesseg.ForeColor = Color.Red;
            else
                txsebesseg.BackColor = Color.White;
                //txsebesseg.ForeColor = Color.Black;
        }

        private void btkilepes_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
