﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace teglalap_szamolas
{
    public partial class frmteglalap : Form
    {
        public frmteglalap()
        {
            InitializeComponent();
        }

        private void frmteglalap_Shown(object sender, EventArgs e)
        {
            lbkerulet.Visible = false;
            lbterulet.Visible = false;
        }

        private void btszamolas_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt16(txaoldal.Text);
            int b = Convert.ToInt16(txboldal.Text);
            int kerulet = 2 * (a + b);
            int terulet = a * b;
            lbkerulet.Text ="A téglalap kerülete: "+ Convert.ToString(kerulet) + " cm";
            lbterulet.Text ="A téglalap területe: "+ Convert.ToString(terulet) + " cm2";
            lbkerulet.Visible = true;
            lbterulet.Visible = true;
        }

        private void btkilepes_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
