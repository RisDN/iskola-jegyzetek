﻿namespace teglalap_szamolas
{
    partial class frmteglalap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbkerulet = new System.Windows.Forms.Label();
            this.lbterulet = new System.Windows.Forms.Label();
            this.txaoldal = new System.Windows.Forms.TextBox();
            this.txboldal = new System.Windows.Forms.TextBox();
            this.btszamolas = new System.Windows.Forms.Button();
            this.btkilepes = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "a oldal hossza:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "b oldal hossza:";
            // 
            // lbkerulet
            // 
            this.lbkerulet.AutoSize = true;
            this.lbkerulet.Location = new System.Drawing.Point(40, 128);
            this.lbkerulet.Name = "lbkerulet";
            this.lbkerulet.Size = new System.Drawing.Size(41, 13);
            this.lbkerulet.TabIndex = 2;
            this.lbkerulet.Text = "label3";
            // 
            // lbterulet
            // 
            this.lbterulet.AutoSize = true;
            this.lbterulet.Location = new System.Drawing.Point(40, 159);
            this.lbterulet.Name = "lbterulet";
            this.lbterulet.Size = new System.Drawing.Size(41, 13);
            this.lbterulet.TabIndex = 3;
            this.lbterulet.Text = "label4";
            // 
            // txaoldal
            // 
            this.txaoldal.Location = new System.Drawing.Point(138, 35);
            this.txaoldal.Name = "txaoldal";
            this.txaoldal.Size = new System.Drawing.Size(78, 20);
            this.txaoldal.TabIndex = 4;
            // 
            // txboldal
            // 
            this.txboldal.Location = new System.Drawing.Point(138, 71);
            this.txboldal.Name = "txboldal";
            this.txboldal.Size = new System.Drawing.Size(78, 20);
            this.txboldal.TabIndex = 5;
            // 
            // btszamolas
            // 
            this.btszamolas.Location = new System.Drawing.Point(296, 37);
            this.btszamolas.Name = "btszamolas";
            this.btszamolas.Size = new System.Drawing.Size(116, 54);
            this.btszamolas.TabIndex = 6;
            this.btszamolas.Text = "Számolás";
            this.btszamolas.UseVisualStyleBackColor = true;
            this.btszamolas.Click += new System.EventHandler(this.btszamolas_Click);
            // 
            // btkilepes
            // 
            this.btkilepes.Location = new System.Drawing.Point(296, 128);
            this.btkilepes.Name = "btkilepes";
            this.btkilepes.Size = new System.Drawing.Size(116, 54);
            this.btkilepes.TabIndex = 7;
            this.btkilepes.Text = "Kilépés";
            this.btkilepes.UseVisualStyleBackColor = true;
            this.btkilepes.Click += new System.EventHandler(this.btkilepes_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(222, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "cm";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(222, 78);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "cm";
            // 
            // frmteglalap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(453, 219);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btkilepes);
            this.Controls.Add(this.btszamolas);
            this.Controls.Add(this.txboldal);
            this.Controls.Add(this.txaoldal);
            this.Controls.Add(this.lbterulet);
            this.Controls.Add(this.lbkerulet);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Name = "frmteglalap";
            this.Text = "Téglalap kerület és terület számítása";
            this.Shown += new System.EventHandler(this.frmteglalap_Shown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbkerulet;
        private System.Windows.Forms.Label lbterulet;
        private System.Windows.Forms.TextBox txaoldal;
        private System.Windows.Forms.TextBox txboldal;
        private System.Windows.Forms.Button btszamolas;
        private System.Windows.Forms.Button btkilepes;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}

