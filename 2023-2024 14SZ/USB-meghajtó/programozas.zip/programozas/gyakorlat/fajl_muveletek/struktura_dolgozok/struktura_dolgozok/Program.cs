﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace struktura_dolgozok
{
    class Program
    {
        public struct dolgozo
        {
            public string nev;
            public int kor;
            public string varos;
            public string neme;
        }

        static void Main(string[] args)
        {
            List<dolgozo> dolgozok = new List<dolgozo>();
            FileStream fs = new FileStream("dolgozok.txt",FileMode.Open);
            StreamReader sr = new StreamReader(fs,Encoding.UTF8);
            string szoveg;
            while(!sr.EndOfStream)
            {
                szoveg = sr.ReadLine();
                string[] sor = szoveg.Split(';');
                dolgozo d = new dolgozo();
                d.nev = sor[0];
                d.kor = Convert.ToInt16(sor[1]);
                d.varos = sor[2];
                d.neme = sor[3];
                dolgozok.Add(d);
            }
            sr.Close();
            fs.Close();
            //dolgozók nevének kiíratása
            for (int i = 0; i < dolgozok.Count; i++)
                Console.WriteLine(dolgozok[i].nev);
            //dolgozók átlag életkorának kiíratása egy tizedesre kerekítve
            double atlag = 0;
            for (int i = 0; i < dolgozok.Count; i++)
            {
                atlag = atlag + dolgozok[i].kor;
            }
            atlag =Math.Round(atlag / dolgozok.Count,1);
            Console.WriteLine("A dolgozók átlag életkora: {0} év",atlag);
            //Adjuk meg, hány férfi és hány nő szerepel a listánkban!
            int ffi=0;
            for (int i = 0; i < dolgozok.Count; i++)
            {
                if (dolgozok[i].neme == "férfi")
                    ffi = ffi + 1;
            }
            int no = dolgozok.Count - ffi;
            Console.WriteLine("Férfiak száma: {0}, nők száma: {1}",ffi,no);
            Console.ReadKey();

        }
        
    }
}
