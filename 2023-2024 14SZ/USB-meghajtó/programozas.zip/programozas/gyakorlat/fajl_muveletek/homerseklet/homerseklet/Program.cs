﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace homerseklet
{
    class Program
    {
        static int[] homerseklet = new int[30];

        static void betoltes()
        {
            FileStream fs = new FileStream("homerseklet.txt", FileMode.Open);
            StreamReader sr = new StreamReader(fs);
            string szoveg = sr.ReadLine();
            string[] tartalom = szoveg.Split(';');
            for (int i = 0; i < tartalom.Length;i++ )
            {
                homerseklet[i] = Convert.ToInt16(tartalom[i]);
            }
            sr.Close();
            fs.Close();
        }

        static void kiiratas()
        {
            for (int i = 0; i < homerseklet.Length; i++)
                Console.WriteLine("Június {0}.: {1}",i+1,homerseklet[i]);
        }

        static bool meleg()
        {
            int j=0;
            while (j < homerseklet.Length && homerseklet[j] < 30)
                j = j + 1;
            if (j < homerseklet.Length)
                return true;
            else
                return false;
        }

        static int leghidegebb()
        {
            int min = 0;
            for(int i=1;i<homerseklet.Length;i++)
            {
                if (homerseklet[i] < homerseklet[min])
                    min = i;
            }
            return min;
        }

        static List<int> valogatas()
        {
            List<int> melegebb = new List<int>();
            for(int i=0;i<homerseklet.Length;i++)
            {
                if (homerseklet[i] > 22)
                    melegebb.Add(i+1);
            }
            return melegebb;
        }
        
        static void Main(string[] args)
        {
            betoltes();
            kiiratas();
            if (meleg())
                Console.WriteLine("Volt 30 foknál melegebb");
            else
                Console.WriteLine("Nem volt 30 foknál melegebb");
            Console.WriteLine("A leghidegebb júniusi nap {0}-án volt, {1} fok.",leghidegebb()+1,homerseklet[leghidegebb()]);
            List<int> mel = valogatas();
            Console.Write("22 foknál melegebb napok:");
            foreach(int szam in mel)
                Console.Write("június {0}., ",szam);
            Console.ReadKey();
        }
    }
}
