﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace fajl_listaba
{
    class Program
    {
        static void Main(string[] args)
        {
// 2)	Olvassa be (listába) a szamok2.txt állományt!
//	a) Írassa ki egymás mellé szóközzel elválasztva a tartalmát!       
            FileStream fs = new FileStream("szamok2.txt",FileMode.Open);
            StreamReader sr = new StreamReader(fs);
            List<double> szamlista = new List<double>();
            string szoveg = sr.ReadLine();
            string[] szamtomb = szoveg.Split(';');
            for (int i = 0; i < szamtomb.Length; i++)
            {
                szamlista.Add(Convert.ToDouble(szamtomb[i]));
            }
            Console.Write("A fájl tartalma: ");
            foreach (int szam in szamlista)
                Console.Write("{0} ",szam);
            sr.Close();
            fs.Close();
            Console.ReadKey();
            
        }
//Házi feladat: 2) feladat folyatatása
//	b) Adja meg a számok összegét, átlagát (két tizedesre kerekítve), legkisebb és legnagyobb elemét!
//	c) Adja meg, hogy tartalmaz-e 3-mal osztható számot!
    }
}
