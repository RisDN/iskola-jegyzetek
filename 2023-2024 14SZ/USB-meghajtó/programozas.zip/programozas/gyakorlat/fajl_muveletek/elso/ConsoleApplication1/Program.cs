﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
//Hozzunk létre a projectünk Debug mappájában egy eletkor.txt fájl, melybe a következőket írjuk be:
 //  51;21;18;29;48
//   Írassuk ki az eletkor.txt fájlban szereplő életkorokat, majd adjuk meg az átlagéletkort! 
            
            FileStream fs = new FileStream("eletkor.txt",FileMode.Open);
            StreamReader sr = new StreamReader(fs);
            string szoveg = sr.ReadLine();

            string[] darabok = szoveg.Split(';');
            int[] eletkor = new int[darabok.Length];
            for (int i = 0; i < darabok.Length;i++ )
            {
                eletkor[i] = Convert.ToInt16(darabok[i]);
                Console.Write("{0} ",eletkor[i]);
            }
            double atlag=0;
            for (int i = 0; i < eletkor.Length;i++ )
            {
                atlag = atlag + eletkor[i];
            }
            atlag = atlag / eletkor.Length;
            Console.WriteLine("\nAz átlag életkor: {0}",atlag);
            Console.ReadKey();
//2) A homerseklet.txt fájl tartalmát írassuk ki! Ez a júniusi napi átlaghőmérsékleteket tartalmazza.
   a) írassuk ki a fájl tartalmát egymás mellé üres hellyel elválasztva
   b) adjuk meg június hónap átlag hőmérsékletét
   c) adjuk meg, hogy hanyadikán volt a legmagasabb hőmérséklet (ne felejtsük el kiíratáskor, hogy a tömb 0-tól számozódik,
      a napok meg 1-től)
   d) válogassuk ki egy új tömbbe, hogy mely napokon volt a napi hőmérséklet 25 fok felett, majd írassuk ki a napokat!
        }
    }
}
