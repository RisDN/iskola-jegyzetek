﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace strukt_ingatlanok
{
    class Program
    {
        //1)	Készítsen egy struktúrát, mely a fájl állományának megfelelő szerkezetű lesz!
        public struct ingatlan
        {     
            public int ar;            
            public int nm;
            public string helyseg;
            public string tipus;
        }
        //2)	Hozzon létre egy közös listát, mely a struktúrának megfelelő!
        public static List<ingatlan> ingtlanok = new List<ingatlan>();

        public static List<ingatlan> csaladihazak = new List<ingatlan>();

        static void csaladihazak_levalogatas()
        {
            for(int j=0;j<ingtlanok.Count;j++)
            {
                if (ingtlanok[j].tipus == "csh")
                    csaladihazak.Add(ingtlanok[j]);
            }
            Console.WriteLine("\n5.feladat");
            for (int j = 0; j < csaladihazak.Count; j++)
                Console.WriteLine("Az ingatlan helye: {0} , nagysága: {1} nm, ára: {2} 000 000 Ft, típusa: {3}", csaladihazak[j].helyseg, csaladihazak[j].nm, csaladihazak[j].ar, csaladihazak[j].tipus);
        }

        static double atlagmeret_szamitas()
        {
            double atlag=0;
            for (int j = 0; j < ingtlanok.Count; j++)
                atlag =atlag+ingtlanok[j].nm;
            atlag = Math.Round(atlag / ingtlanok.Count, 1);
            return atlag;
        }

        static void Main(string[] args)
        {
            //3)	Töltse be a fájl adatait a listába!
            FileStream fs = new FileStream("ingatlan.txt", FileMode.Open);
            StreamReader sr = new StreamReader(fs, Encoding.UTF8);
            string szoveg;
            while (!sr.EndOfStream)
            {
                szoveg = sr.ReadLine();
                string[] sor = szoveg.Split(';');
                ingatlan i = new ingatlan();
                i.ar =Convert.ToInt16(sor[0]);           
                i.nm =Convert.ToInt16(sor[1]);
                i.helyseg = sor[2];
                i.tipus = sor[3];
                ingtlanok.Add(i);
            }
            sr.Close();
            fs.Close();
            Console.WriteLine("1-3 feladat kész! Adatok betöltve!");
            //4)	Írassa ki konzolra a fájl tartalmát!
            Console.WriteLine("\n4.feladat");
            for (int j = 0; j < ingtlanok.Count; j++)
                Console.WriteLine("Az ingatlan helye: {0} , nagysága: {1} nm, ára: {2} 000 000 Ft, típusa: {3}", ingtlanok[j].helyseg,ingtlanok[j].nm,ingtlanok[j].ar,ingtlanok[j].tipus);
            //5)	A „családi ház” típusú ingatlanok adatait tegye bele egy új listába, majd írassa ki azokat! 
            //      A feladatmegoldást egy eljárás segítségével valósítsa meg!
            csaladihazak_levalogatas();
            //6)	Egy függvény segítségével számolja ki az ingatlanok átlag méretét (egy tizedesre kerekítve),
            //      majd a főfüggvényből írassa ki azt a konzolra!
            Console.WriteLine("\n6.feladat");
            Console.WriteLine("Az ingatlanok átlagos mérete: {0} nm", atlagmeret_szamitas());
            //7)	A 60 négyzetméternél nagyobb, panellakás típusú ingatlanok adatait mentsük el egy fájlba,
            //      melynek neve legyen: ugyfeltalalat.txt
            fs = new FileStream("ugyfeltalalat.txt",FileMode.Append);
            StreamWriter sw = new StreamWriter(fs);
            for (int j = 0; j < ingtlanok.Count; j++)
            {
                if((ingtlanok[j].nm>60) && (ingtlanok[j].tipus=="pl"))
                {
                    sw.WriteLine("{0};{1};{2};{3}",ingtlanok[j].ar,ingtlanok[j].nm,ingtlanok[j].helyseg,ingtlanok[j].tipus);
                }
            }
            sw.Close();
            fs.Close();
            Console.WriteLine("\nAz ugyfeltalalat.txt fájl feltöltve!");
            //8)	Kérje be a felhasználótól, hogy mekkora legyen a keresett ingatlan legmagasabb ára,
            //      majd írassa ki konzolra az ennek megfelelő ingatlanok adatait!
            Console.WriteLine("\n8.feladat");
            Console.WriteLine("Adja meg, hogy mekkora árig (MFt) keres ingatlant!");
            int kermeret = Convert.ToInt16(Console.ReadLine());
            for (int j = 0; j < ingtlanok.Count; j++)
            {
                if(ingtlanok[j].ar<=kermeret)
                    Console.WriteLine("Az ingatlan helye: {0} , nagysága: {1} nm, ára: {2} 000 000 Ft, típusa: {3}", ingtlanok[j].helyseg, ingtlanok[j].nm, ingtlanok[j].ar, ingtlanok[j].tipus);
            }

                Console.ReadKey();
        }
    }
}
