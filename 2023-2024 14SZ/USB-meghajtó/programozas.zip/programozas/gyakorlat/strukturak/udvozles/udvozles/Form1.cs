﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace udvozles
{
    public partial class frmudvozles : Form
    {
        public frmudvozles()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btmehet_Click(object sender, EventArgs e)
        {
            string szoveg = txnev.Text;
            MessageBox.Show("Üdvözöllek "+szoveg+"!");
            lbudvozles.Visible = true;
            lbudvozles.Text = "Helló " + szoveg + "!";
        }

        private void frmudvozles_Shown(object sender, EventArgs e)
        {
            //lbudvozles.Text = "";
            lbudvozles.Visible = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
