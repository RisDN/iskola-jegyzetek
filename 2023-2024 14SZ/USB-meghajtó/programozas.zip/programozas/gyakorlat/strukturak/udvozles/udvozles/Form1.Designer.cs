﻿namespace udvozles
{
    partial class frmudvozles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txnev = new System.Windows.Forms.TextBox();
            this.btmehet = new System.Windows.Forms.Button();
            this.lbudvozles = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(28, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Írja be a kedvenc ételét:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txnev
            // 
            this.txnev.Location = new System.Drawing.Point(187, 21);
            this.txnev.Name = "txnev";
            this.txnev.Size = new System.Drawing.Size(100, 20);
            this.txnev.TabIndex = 1;
            // 
            // btmehet
            // 
            this.btmehet.Location = new System.Drawing.Point(239, 181);
            this.btmehet.Name = "btmehet";
            this.btmehet.Size = new System.Drawing.Size(75, 23);
            this.btmehet.TabIndex = 2;
            this.btmehet.Text = "Kiíratás";
            this.btmehet.UseVisualStyleBackColor = true;
            this.btmehet.Click += new System.EventHandler(this.btmehet_Click);
            // 
            // lbudvozles
            // 
            this.lbudvozles.AutoSize = true;
            this.lbudvozles.ForeColor = System.Drawing.Color.Red;
            this.lbudvozles.Location = new System.Drawing.Point(40, 82);
            this.lbudvozles.Name = "lbudvozles";
            this.lbudvozles.Size = new System.Drawing.Size(41, 13);
            this.lbudvozles.TabIndex = 3;
            this.lbudvozles.Text = "label2";
            // 
            // frmudvozles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(590, 274);
            this.Controls.Add(this.lbudvozles);
            this.Controls.Add(this.btmehet);
            this.Controls.Add(this.txnev);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Name = "frmudvozles";
            this.Text = "Házi feladat";
            this.Shown += new System.EventHandler(this.frmudvozles_Shown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txnev;
        private System.Windows.Forms.Button btmehet;
        private System.Windows.Forms.Label lbudvozles;
    }
}

