﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace strukt_szalloda
{
 
    class Program
    {
        public struct szalloda
        {
            public string nev;
            public int ejszam;
            public int vendegszam;
            public string ellatas;
        }
        
        static public List<szalloda> vendegek=new List<szalloda>();
        static public List<szalloda> torzsvendegek=new List<szalloda>();

        static void feltoltes()
        {
            FileStream fs=new FileStream("vendegek.txt",FileMode.Open);
            StreamReader sr=new StreamReader(fs,Encoding.UTF8);
            string sor;
            while(!sr.EndOfStream)
            {
                sor=sr.ReadLine();
                string[] darabok=sor.Split(';');
                szalloda v = new szalloda();
                v.nev = darabok[0];
                v.ejszam = Convert.ToInt16(darabok[1]);
                v.vendegszam = Convert.ToInt16(darabok[2]);
                v.ellatas = darabok[3];
                vendegek.Add(v);
            }
            sr.Close();
            fs.Close();
        }

        static void vendegekkiiratas()
        {
            for(int i=0; i<vendegek.Count;i++)
            {
                Console.WriteLine("Vendég neve: {0}, éjszakák száma: {1}, személyek száma: {2}, ellátás típusa: {3}", vendegek[i].nev,vendegek[i].ejszam,vendegek[i].vendegszam,vendegek[i].ellatas);
            }
        }

        static int szumvengegejszakak()
        {
            int osszes = 0;
            for(int i=0; i<vendegek.Count;i++)
            {
                osszes = osszes + vendegek[i].ejszam * vendegek[i].vendegszam;
            }
            return osszes;
        }       

        static void torzsvalogatas()
        {
            for (int i = 0; i < vendegek.Count;i++ )
            {
                if (vendegek[i].ejszam > 4)
                    torzsvendegek.Add(vendegek[i]);
            }
            Console.WriteLine("A törzsvendégeink adatai:");
            for (int i = 0; i < torzsvendegek.Count; i++)
            {
                Console.WriteLine("Vendég neve: {0}, éjszakák száma: {1}, személyek száma: {2}, ellátás típusa: {3}", torzsvendegek[i].nev, torzsvendegek[i].ejszam, torzsvendegek[i].vendegszam, torzsvendegek[i].ellatas);
            }
        }

        static void fajlbairas()
        {
            FileStream fs = new FileStream("torzsvendegek.txt", FileMode.Append);
            StreamWriter sw = new StreamWriter(fs);
            for (int i = 0; i < torzsvendegek.Count; i++)
                sw.WriteLine("{0};{1};{2};{3}",torzsvendegek[i].nev,torzsvendegek[i].ejszam,torzsvendegek[i].vendegszam,torzsvendegek[i].ellatas);
            sw.Close();
            fs.Close();
        }

        static string ellataslekerdezes(string ellatas)
        {
            string nevek="";
            for(int i=0;i<vendegek.Count;i++)
            {
                if(vendegek[i].ellatas==ellatas)
                {
                    nevek = nevek + ", " + vendegek[i].nev;
                }
            }
            return nevek;
        }

        static void Main(string[] args)
        {
            feltoltes();
            vendegekkiiratas();
            Console.WriteLine("A vendégéjszakák száma: {0}",szumvengegejszakak());
            torzsvalogatas();
            fajlbairas();
            Console.WriteLine("Adja meg az ellátás típusát:");
            string tipus = Console.ReadLine();
            Console.WriteLine("Ezt a szolgáltatás az alábbi vendégek vették igénybe: {0}",ellataslekerdezes(tipus));
            Console.ReadKey();
        }
    }
}
