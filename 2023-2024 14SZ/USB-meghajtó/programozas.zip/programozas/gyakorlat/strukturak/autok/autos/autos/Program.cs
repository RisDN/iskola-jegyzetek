﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace autos
{
    class Program
    {
        //1)	Készítsen egy struktúrát, mely a fájl állományának megfelelő szerkezetű lesz!
        public struct auto
        {
            public string rendszam;
            public int fogyasztas;
            public int km;
            public string tipus;
        }
        //2)	Hozzon létre egy közös listát, mely a struktúrának megfelelő!
        public static List<auto> autok = new List<auto>();

        public static List<auto> szemelygepjarmuvek = new List<auto>();

        static void szemelygepjarmu_levalogatas()
        {
            for (int j = 0; j < autok.Count; j++)
            {
                if (autok[j].tipus == "szg")
                    szemelygepjarmuvek.Add(autok[j]);
            }
            Console.WriteLine("\n7.feladat");
            for (int j = 0; j < szemelygepjarmuvek.Count; j++)
                Console.WriteLine("Az autó rendszáma: {0} , fogyasztása: {1} l/100km, futott km: {2}, típusa: {3}", szemelygepjarmuvek[j].rendszam, szemelygepjarmuvek[j].fogyasztas, szemelygepjarmuvek[j].km, szemelygepjarmuvek[j].tipus);
        }

        static int legkevesebb_km()
        {
            int min=0;
            for (int j = 1; j < autok.Count; j++)
            {
                if (autok[j].km < autok[min].km)
                    min = j;
            }
            return min;
        }

        static void Main(string[] args)
        {
            //3)	Töltse be a fájl adatait a listába!
            FileStream fs = new FileStream("autok.txt", FileMode.Open);
            StreamReader sr = new StreamReader(fs, Encoding.UTF8);
            string szoveg;
            while (!sr.EndOfStream)
            {
                szoveg = sr.ReadLine();
                string[] sor = szoveg.Split(';');
                auto a = new auto();
                a.rendszam = sor[0];
                a.fogyasztas = Convert.ToInt16(sor[1]);
                a.km =Convert.ToInt16(sor[2]);
                a.tipus = sor[3];
                autok.Add(a);
            }
            sr.Close();
            fs.Close();
            Console.WriteLine("1-3 feladat kész! Adatok betöltve!");
            //4)	Írassa ki konzolra a fájl tartalmát!
            Console.WriteLine("\n4.feladat");
            for (int j = 0; j < autok.Count; j++)
                Console.WriteLine("Az autó rendszáma: {0} , fogyasztása: {1} l/100km, futott km: {2}, típusa: {3}", autok[j].rendszam, autok[j].fogyasztas, autok[j].km, autok[j].tipus);
            //5)	Egy függvény segítségével határozza meg a legkevesebb km-t futott autóját, majd a főfüggvényből írassa ki annak rendszámát!
            Console.WriteLine("\n5.feladat");
            Console.WriteLine("A legkevesebbet futott autó rendszáma: {0} nm", autok[legkevesebb_km()].rendszam);
            //6)	Határozza meg a gépkocsik átlagos fogyasztását két tizedesre kerekítve!
            Console.WriteLine("\n6.feladat");
            double atlag = 0;
            for (int j = 0; j < autok.Count; j++)
                atlag = atlag + autok[j].fogyasztas;
            atlag = Math.Round(atlag/autok.Count,2);
            Console.WriteLine("Az gépkocsik átlagos fogyasztása: {0} l",atlag);
            //7)	A „személygépjármű” típusú gépkocsik adatait tegye bele egy új listába, majd írassa ki azokat! A feladatmegoldást egy eljárás segítségével valósítsa meg!
            szemelygepjarmu_levalogatas();
            //7)	8)	A 10 liternél kevesebb fogyasztású autók adatait mentsük el (pontosvesszővel elválasztva,
            //sortöréssel) egy fájlba, melynek neve legyen: kisfogyasztasuak.txt
            fs = new FileStream("kisfogyasztasuak.txt", FileMode.Append);
            StreamWriter sw = new StreamWriter(fs);
            for (int j = 0; j < autok.Count; j++)
            {
                if (autok[j].fogyasztas < 10)
                {
                    sw.WriteLine("{0};{1};{2};{3}", autok[j].rendszam, autok[j].fogyasztas, autok[j].km, autok[j].tipus);
                }
            }
            sw.Close();
            fs.Close();
            Console.WriteLine("\nA kisfogyasztásúak.txt fájl feltöltve!");

            Console.ReadKey();
        }
    }
}
