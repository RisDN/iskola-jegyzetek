﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace orai_0217
{
class Diak {
    public Diak(string n, int e, int isz) 
    {
        Nev = n; Eletkor = e; Iranyitószam = isz;
    }
    private string nev;
    public string Nev 
    {
        get { return nev; }
        set { nev = value; }
    }
    private int eletkor;
    public int Eletkor 
    {
        get { return eletkor; }
        set { eletkor = value;}
    }
    private int iranyitoszam;
    public int Iranyitoszam {
        get { return iranyitoszam; }
        set { irányitoszam = value; }
}
    {
        

        static void Main(string[] args)
        {
            
        }
    }
}
