﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace kutyikak
{
    class Program
    {
//A kutyak.txt fájlban szerepelnek egy állatorvosi rendelő kutya betegeinek néhány adata, mely a következőket
//tartalmazza: név, fajta, nem és életkor sorrendben.
//a) Készítsen egy struktúrát, amely megfelel a fájlban szereplő adatoknak!
//b) Készítsen egy listát, amely a struktúrának megfelelő, majd olvassa be a fájlban lévő adatokat a listába!
       public struct kutya
        {     
            public string nev;            
            public string fajta;
            public string nem;
            public int kor;
        }

        static void Main(string[] args)
        {
            List<kutya> kutyak = new List<kutya>();
            FileStream fs = new FileStream("kutyak.txt", FileMode.Open);
            StreamReader sr = new StreamReader(fs, Encoding.UTF8);
            string szoveg;
            while (!sr.EndOfStream)
            {
                szoveg = sr.ReadLine();
                string[] sor = szoveg.Split(';');
                kutya k = new kutya();
                k.nev = sor[0];           
                k.fajta = sor[1];
                k.nem = sor[2];
                k.kor = Convert.ToInt16(sor[3]);
                kutyak.Add(k);
            }
            sr.Close();
            fs.Close();
            //c) Írassa ki a kutyák nevét!
            for (int i = 0; i < kutyak.Count; i++)
                Console.WriteLine(kutyak[i].nev);
            //d) Írassa ki a legidősebb kutya fajtáját!
            int max = 0;
            for(int i=1; i<kutyak.Count;i++)
            {
                if (kutyak[i].kor > kutyak[max].kor)
                    max = i;
            }
            Console.WriteLine("A legidősebb kutya fajtája: {0}", kutyak[max].fajta);

            //e) Írassa ki a kutyák átlag életkorát!
            double atlag = 0;
            for (int i = 0; i < kutyak.Count; i++)
            {
                atlag = atlag + kutyak[i].kor;
            }
            atlag = Math.Round(atlag / kutyak.Count, 1);
            Console.WriteLine("A kutyák átlag életkora: {0} év", atlag);
            //f) Írassa ki, hogy hány szuka és hány kan kutya szerepel a listában!
            int kan = 0;
            for (int i = 0; i < kutyak.Count; i++)
            {
                if (kutyak[i].nem == "kan")
                    kan = kan + 1;
            }
            int szuka = kutyak.Count - kan;
            Console.WriteLine("A kan kutyák száma: {0}, a szuka kutyák száma: {1}", kan, szuka);
            //g) Egy listába rakja az 5 évesnél fiatalabb szuka kutyák nevét, majd írassa ki annak tartalmát! 
            List<string> szukak=new List<string>();
            for(int i=0;i<kutyak.Count;i++)
            {
                if(kutyak[i].kor<5 && kutyak[i].nem=="szuka")
                    szukak.Add(kutyak[i].nev);
            }
            Console.Write("Az 5 évnél fiatalabb szukák neve: ");
            for(int i=0;i<szukak.Count;i++)
                Console.Write("{0}, ",szukak[i]);

            //a) Írassuk a kutyak fájl utolsó sorába az 5 évesnél fiatalabb szukák nevét
            //b)Hozzuk létre programból a kutyikak.txt fájlt, és írasssuk bele az 5 évesnél fiatalabb szukák nevét
            //c) Hozzuk létre programból az oregkutyak.txt fájlt és írassuk bele az 5 évesnél idősebb kutyák nevét és korát
  // pontosvesszővel elválasztva!
            fs = new FileStream("oregkutyak.txt", FileMode.Append);
            StreamWriter sw = new StreamWriter(fs);

            for(int i=0;i<kutyak.Count;i++)
            {
                if (kutyak[i].kor > 5)
                    sw.WriteLine("{0};{1}",kutyak[i].nev,kutyak[i].kor);
            }
            sw.Close();
            fs.Close();
            
//d) Hozzuk létre programból nemkolyok.txt fájlt, és írja bele a 2 évesnél idősebb kutyák minden adatát, pontosvesszővel elválasztva.
e) Hozzon létre egy struktktúrát, mely a ennek a fájlnak a tartalmát tudja tárolni, és egy listába
   töltse be az adatokat!
f) Írassa ki a kutyák nevét!
g) Írassa ki az átlag korukat 1 tizedesre kerekítve!
            
    
    Console.ReadKey();

        }

    }
}
