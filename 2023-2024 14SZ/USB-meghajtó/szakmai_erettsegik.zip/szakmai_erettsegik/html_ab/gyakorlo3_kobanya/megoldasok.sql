﻿-- A feladatok megoldására elkészített SQL parancsokat illessze be a feladat sorszáma után!

-- 8. feladat:



-- 10. feladat:



-- 11. feladat:



-- 12. feladat:



-- 13. feladat:



-- 14. feladat:


