﻿-- A feladatok megoldására elkészített SQL parancsokat illessze be a feladat sorszáma után!


-- 8. feladat:
CREATE DATABASE konyvtarak
	DEFAULT CHARACTER SET utf8
	COLLATE UTF8_HUNGARIAN_CI;

-- 10. feladat:
UPDATE megyek
SET megyeNev="Budapest"
WHERE megyeNev="BP";

-- 11. feladat:
SELECT konyvtarNev, irsz
FROM konyvtarak
WHERE konyvtarNev LIKE "%Szakkönyvtár%";

-- 12. feladat:
SELECT 
	konyvtarNev,
	irsz,
	cim
FROM konyvtarak
WHERE 
	irsz>=1000 
	AND irsz<2000
ORDER BY irsz;

-- 13. feladat:
SELECT
	telepulesek.telepNev AS telepNev,
	COUNT(konyvtarak.id) AS konyvtarDarab
FROM telepulesek, konyvtarak
WHERE telepulesek.irsz=konyvtarak.irsz
GROUP BY telepNev
HAVING konyvtarDarab>=7
ORDER BY telepNev;

-- 14. feladat:
SELECT megyek.megyeNev AS megyeNev,
	COUNT(telepulesek.irsz) AS telepulesDarab
FROM megyek, telepulesek
WHERE
   megyek.id=telepulesek.megyeId
	AND megyek.megyeNev NOT IN ("Budapest")
GROUP BY megyenev
ORDER BY telepulesDarab DESC;

