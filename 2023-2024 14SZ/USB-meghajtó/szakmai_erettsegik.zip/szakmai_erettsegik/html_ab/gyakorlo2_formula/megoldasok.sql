-- A feladatok megold�s�ra elk�sz�tett SQL parancsokat illessze be a feladat sorsz�ma ut�n!


-- 1. feladat:


-- 3. feladat:


-- 4. feladat:


-- 5. feladat:


-- 6. feladat:

